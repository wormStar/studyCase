package cn.stu.common;

/**
 * Created by sweet on 2017/7/6.
 */
public class ControllerResult {

    private String result;
    private String message;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private static final String SUCCESS = "success";
    private static final String FAIL = "fail";

    public static ControllerResult getSuccessResult(String message) {
        ControllerResult controllerResult = new ControllerResult();
        controllerResult.setMessage(SUCCESS);
        controllerResult.setResult(message);
        return controllerResult;
    }

    public static ControllerResult getFailResult(String message) {
        ControllerResult controllerResult = new ControllerResult();
        controllerResult.setResult(FAIL);
        controllerResult.setMessage(message);
        return controllerResult;
    }

}
