package cn.stu.service;

import cn.stu.bean.Product;
import cn.stu.common.Pager;
import cn.stu.dao.ProductDAO;
import cn.stu.dao.impl.ProductDAOImpl;

import java.util.List;

/**
 * Created by sweet on 2017/7/6.
 */
public class ProductServiceImpl implements ProductService {

    private ProductDAO productDAO;

    public ProductServiceImpl() {
        productDAO = new ProductDAOImpl();
    }

    public void add(Product product) {
        productDAO.add(product);
    }

    public void update(Product product) {
        productDAO.update(product);
    }

    public List<Product> all() {
        return productDAO.all();
    }

    public Product findById(Integer integer) {
        return productDAO.findById(integer);
    }

    public Product delete(Integer integer) {
        return productDAO.delete(integer);
    }

    public int count() {
        return productDAO.count();
    }

    public void valid(Integer integer, String status) {
        productDAO.valid(integer, status);
    }

    public Pager<Product> queryByPager(Pager<Product> pager) {
        return productDAO.queryByPager(pager);
    }
}
