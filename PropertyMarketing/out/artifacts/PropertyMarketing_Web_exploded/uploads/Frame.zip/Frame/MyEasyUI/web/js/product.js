function showAddWin() {
    $("#addPro").window("open");
}

function closeWin() {
    $("#addPro").window("close");
}

function showEditWin() {
    var jsonStr = '{"product.id":id_value,"product.name":"name_value","product.count":count_value,"product.price":price_value,"product.salePrice":salePrice_value,"product.date":"date_value"}';
    var row = $("#list").datagrid("getSelected");// 获取数据网格中被选择的单行 getSelections获取数据网格中选中的多行
    if(row){
        jsonStr = jsonStr.replace("id_value",row.id).replace("name_value",row.name).replace("count_value",row.count).replace("price_value",row.price).replace("salePrice_value",row.salePrice).replace("date_value",row.date);
        $("#editProForm").form("load", JSON.parse(jsonStr));// 自动把json对象加载到form表单，form里的name与json数据里的属性保持一致
        $("#editPro").window("open");// JSON.parse把json字符串转成json对象，JSON.stringify,把JSON对象转成JSON字符串
    }else{
        showAlert("请选择需要编辑的商品");
    }

}

function addPro() {
    if($('#addProForm').form('enableValidation').form('validate')) {
        $.post("/product/add",
            $("#addProForm").serialize(),
            function(data){
                if(data.controllerResult.result == 'success'){
                   showAlert("添加成功");
                  $("#addPro").window("close");
                  $("#list").datagrid("reload");
                  $("#addProForm").form("clear");
                }
            },
            'json'
        );
    }else{
        showAlert("信息不完整");
    }
}

function editPro() {
    if($('#editProForm').form('enableValidation').form('validate')) {
        $.post("/product/update",
            $("#editProForm").serialize(),
            function(data){
                if(data.controllerResult.result == 'success'){
                    showAlert("修改成功");
                    $("#list").datagrid("reload");
                    $("#editPro").window("close");
                    $("#editProForm").form("clear");
                }
            },
            'json'
        );
    }else{
        showAlert("信息不完整");
    }
}

function valid(status) {
    var row = $("#list").datagrid("getSelected");
   if(row){
      if(row.status == status) {
          showAlert("无需" + (status == 'Y' ? "激活" : "冻结") + "该商品！");
          return;
      }
       var json;
       if(status == 'Y'){
           json = {
               "status" : "Y",
               "id" : row.id
           }
       }else if(status == 'N'){
           json = {
               "status" : "N",
               "id" : row.id
           }
       }
        $.post("/product/valid",
            json,
            function(data) {
                if(data.controllerResult.result == 'success'){
                    showAlert(data.controllerResult.message);
                    $("#list").datagrid("reload");
                }else{
                    showAlert(data.controllerResult.message);
                }
            },
            "json"
        );
   }else{
       showAlert("请选择需要" + (status == 'Y' ? "激活" : "冻结") + "的商品！");
   }
}


