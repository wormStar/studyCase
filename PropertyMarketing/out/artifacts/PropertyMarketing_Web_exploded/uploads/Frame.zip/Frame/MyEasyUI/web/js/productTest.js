function add() {
    if($('#addProduct').form('enableValidation').form('validate')) {
        alert("验证成功");
    }else{
        alert("信息不完整");
    }
}