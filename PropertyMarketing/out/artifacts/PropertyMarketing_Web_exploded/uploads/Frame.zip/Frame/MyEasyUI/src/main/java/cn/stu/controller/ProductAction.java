package cn.stu.controller;

import cn.stu.bean.Product;
import cn.stu.common.ControllerResult;
import cn.stu.common.Pager;
import cn.stu.service.ProductService;
import cn.stu.service.ProductServiceImpl;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.ServletRequestAware;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by sweet on 2017/7/6.
 */
public class ProductAction extends ActionSupport implements ServletRequestAware {

    private HttpServletRequest request;
    private int total;
    private List<Product> rows;
    private Product product;
    private int page;
    private ControllerResult controllerResult;

    private int id;
    private String status;

    private ProductService productService;


    public ProductAction() {
        productService = new ProductServiceImpl();
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public ControllerResult getControllerResult() {
        return controllerResult;
    }




    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal() {
        return total;
    }

    public List<Product> getRows() {
        return rows;
    }

    public String add(){
        productService.add(product);
        controllerResult = ControllerResult.getSuccessResult("success");
        return "add";
    }

    public String update() {
        productService.update(product);
        controllerResult = ControllerResult.getSuccessResult("success");
        return "update";
    }

    public String pager() {
        rows = new ArrayList<Product>();
        int pageSize = Integer.valueOf(request.getParameter("rows"));
        Pager<Product> pager = new Pager<Product>();
        pager.setPage(page);
        pager.setPageSize(pageSize);
        pager = productService.queryByPager(pager);
        total = productService.count();
        rows = pager.getResults();
        return "pager";
    }

    public String valid() {
        productService.valid(id, status);
        if("Y".equals(status)) {
            controllerResult = ControllerResult.getSuccessResult("success");
        }else if("N".equals(status)) {
            controllerResult = ControllerResult.getSuccessResult("success");
        }
        return "valid";
    }

    public void setServletRequest(HttpServletRequest httpServletRequest) {
        this.request = httpServletRequest;
    }
}
