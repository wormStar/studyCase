function openDlg(){
    $("#dlg").dialog("open");
}

function openWin() {
    $("#win").window("open");
}

function openMessage() {
    $.messager.confirm('提示', '确定删除?', function(r){
        if (r){
            alert('confirmed: '+r);
        }
    });
}

function start(){
    var value = $('#p').progressbar('getValue');
    if (value < 100){
        value += Math.floor(Math.random() * 10);
        $('#p').progressbar('setValue', value);
        setTimeout(arguments.callee, 200);
    }
};





