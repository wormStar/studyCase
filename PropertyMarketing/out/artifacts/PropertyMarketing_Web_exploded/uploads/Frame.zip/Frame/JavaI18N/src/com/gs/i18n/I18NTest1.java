package com.gs.i18n;

import java.security.Key;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Created by sweet on 2017/6/28.
 */
public class I18NTest1 {

    public static void main(String []args) {
        //Locale locale = new Locale("en", "US"); // 语言及国家代码的区域对象
        Locale locale = Locale.getDefault();
        System.out.println(locale.getLanguage());
        System.out.println(locale.getCountry());

        DateFormat dateFormat = DateFormat.getDateInstance(0, locale);
        System.out.println(dateFormat.format(Calendar.getInstance().getTime()));

        ResourceBundle rb = ResourceBundle.getBundle("resource", locale);
        System.out.println(rb.getString("test"));
    }
}
