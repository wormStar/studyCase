package cn.stu.user;

/**
 * Created by sweet on 2017/6/25.
 */
public class Test1 {

    public void hello() {
        new Thread(new Runnable() {
            public void run() {
                String str = Test2.tl.get();
                System.out.println(str);
            }
        });
//        String str = Test2.tl.get();
//        System.out.println(str);
    }

}
