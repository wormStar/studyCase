package cn.stu.controller;

/**
 * Created by sweet on 2017/6/21.
 */
public class MoreMethodAction {

    public String execute() {
        return "study";
    }

    public String add() {
        return "add";
    }
}
