package cn.stu.controller;

import cn.stu.Util.FileUtil;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

/**
 * Created by sweet on 2017/6/29.
 */
public class UploadAction extends ActionSupport {

    public File upload;
    public String uploadFileName;
    public String uploadContentType;

    public void setUpload(File upload) {
        this.upload = upload;
    }

    public void setUploadFileName(String uploadFileName) {
        this.uploadFileName = uploadFileName;
    }

    public void setUploadContentType(String uploadContentType) {
        this.uploadContentType = uploadContentType;
    }

    public String execute() {
        try {
            FileUtils.copyFile(upload, new File(FileUtil.uploadPath() + File.separator + uploadFileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(new File(FileUtil.uploadPath() + File.separator + uploadFileName));
        System.out.println(upload);
        System.out.println(uploadFileName);
        System.out.println(uploadContentType);
        return SUCCESS;
    }

}
