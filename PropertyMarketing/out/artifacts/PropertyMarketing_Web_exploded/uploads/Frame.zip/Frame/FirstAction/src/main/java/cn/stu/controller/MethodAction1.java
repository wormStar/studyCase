package cn.stu.controller;

/**
 * Created by sweet on 2017/6/21.
 */
public class MethodAction1 {

    public String execute() {
        return "execute";
    }

    public String add() {
        return "add";
    }

    public String update() {
        return "update";
    }

    public String delete() {
        return "delete";
    }

    public String find() {
        return "find";
    }

}
