package cn.stu.user;

/**
 * Created by sweet on 2017/6/22.
 */
public class User {

    private String email;
    private String pwd;
    private String sex;

    public String getEmail() {
        return email;
    }

    public String getPwd() {
        return pwd;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public String add() {
        System.out.println(email + "," + pwd);
        return "add";

    }
    public String regPage() {
        return "regPage";
    }

}
