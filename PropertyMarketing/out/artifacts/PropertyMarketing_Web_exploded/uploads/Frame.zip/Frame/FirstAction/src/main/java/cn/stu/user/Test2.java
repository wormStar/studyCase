package cn.stu.user;

/**
 * Created by sweet on 2017/6/25.
 */
public class Test2 {

    public static ThreadLocal<String> tl = new ThreadLocal<String>();

    public static void main(String[] args){
        tl.set("test");
        String s = tl.get();
        new Test1().hello();
        //System.out.println(s);
    }
}
