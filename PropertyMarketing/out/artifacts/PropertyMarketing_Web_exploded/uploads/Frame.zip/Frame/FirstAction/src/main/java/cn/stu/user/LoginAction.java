package cn.stu.user;

/**
 * Created by sweet on 2017/6/22.
 */
public class LoginAction {
    private User user;
    private String errorMsg;

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public User getUser() {

        return user;
    }

    public String loginCheck() {
       if("123@.com".equals(user.getEmail())){
           return "success";
       }else{
            this.errorMsg = "您的邮箱或密码错误";
           return "login";
       }
    }

}
