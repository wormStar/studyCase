package cn.stu.controller;

import com.opensymphony.xwork2.ActionSupport;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sweet on 2017/6/29.
 */
public class JSONAction extends ActionSupport {

    private int a;
    private String b;
    private List<String> array;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public List<String> getArray() {
        return array;
    }

    public void setArray(List<String> array) {
        this.array = array;
    }

    public String execute() {
        a = 10;
        b = "study";
        array = new ArrayList<String>();
        array.add("first");
        array.add("second");
        System.out.println(a + "," + "b" + array);

        return "success";
    }
}
