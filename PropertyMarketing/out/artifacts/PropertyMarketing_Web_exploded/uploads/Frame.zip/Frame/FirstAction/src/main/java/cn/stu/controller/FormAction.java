package cn.stu.controller;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Created by sweet on 2017/6/28.
 */
public class FormAction extends ActionSupport {
    private String name;
    private String des;
    private String sex;
    private String[] hobby;
    private String job;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String[] getHobby() {
        return hobby;
    }

    public void setHobby(String[] hobby) {
        this.hobby = hobby;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
    public String page() {
        name = "mary";
        sex = "woman";
        hobby = new String[]{"travel", "music"};
        job = "teacher";
        return "page";
    }

    public String person() {
        System.out.println(name + ',' + des + ',' + sex + ',' + hobby + ',' + job);
        return "person";
    }

}
