package cn.stu.controller;

import com.opensymphony.xwork2.ActionContext;
import org.apache.struts2.ServletActionContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Created by sweet on 2017/6/23.
 */
public class ServletAction {

    public String execute() {
        ServletContext application = ServletActionContext.getServletContext();
        HttpServletRequest request = ServletActionContext.getRequest();
        HttpServletResponse response = ServletActionContext.getResponse();
        HttpSession session = request.getSession();

        ActionContext actionContext = ActionContext.getContext();
        Map<String, Object> sess = actionContext.getSession();// Struts封装的session对象，此session是一个Map结构，与原生session可共享数据
        Map<String, Object> applica = actionContext.getApplication();
        Map<String, Object>  req = (Map<String, Object>)actionContext.get("request");

        return "success";
    }

}
