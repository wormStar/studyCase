package cn.stu.intercepter;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

import java.util.Map;

/**
 * Created by sweet on 2017/6/26.
 */
public class MyIntercepter extends AbstractInterceptor {
    @Override
    public String intercept(ActionInvocation actionInvocation) throws Exception {
        System.out.println("进入自定义拦截器");
        ActionContext actionContext = actionInvocation.getInvocationContext();
        Map<String, Object> params = actionContext.getParameters();
        String[] strArray = (String[]) params.get("name");
        String result;
        if(strArray != null && strArray.length > 0) {
            System.out.println("输入的数据是" + strArray[0]);
            if(strArray != null && strArray[0].equals("mary")){
                result = actionInvocation.invoke();
            }else{
                result = "input";
            }
        }else{
            result = "input";
        }
        return result;
    }
}
