package cn.stu.intercepter;

/**
 * Created by sweet on 2017/6/27.
 */
public class MethodInterceptorTest {

    public String add() {
        return "add";
    }

    public String update() {
        return "update";
    }

    public String delete() {
        return "delete";
    }

}
