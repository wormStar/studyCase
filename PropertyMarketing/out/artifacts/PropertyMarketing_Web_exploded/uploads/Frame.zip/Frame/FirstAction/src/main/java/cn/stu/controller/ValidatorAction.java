package cn.stu.controller;

/**
 * Created by sweet on 2017/6/26.
 */
public class ValidatorAction {

    private String name;
    private String pwd;
    private String conPwd;
    private int phone;

    public void setName(String name) {
        this.name = name;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public void setConPwd(String conPwd) {
        this.conPwd = conPwd;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getPwd() {
        return pwd;
    }

    public String getConPwd() {
        return conPwd;
    }

    public int getPhone() {
        return phone;
    }

    public String execute() {
        System.out.println("name:" + name +",pwd:" + pwd + ",conPwd:" + conPwd + ",phone:" + phone);
        return "success";
    }

}
