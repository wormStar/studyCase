package cn.stu.user;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Created by sweet on 2017/6/22.
 */
public class User1 extends ActionSupport {

    private User user;

    public void setUser(User user) {
        this.user = user;
    }

    public String regPage() {
        return "regPage";
    }

    public String prints() {
        System.out.println(user.getEmail() +"," + user.getPwd() +"," + user.getSex());
        return "prints";
    }
}
