package cn.stu.controller;

/**
 * Created by sweet on 2017/6/21.
 */
public class TestAction {

    public String execute() {
        return "success";
    }

}
