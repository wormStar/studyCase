package cn.stu.Util;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;

import java.io.File;

/**
 * Created by sweet on 2017/6/29.
 */
public class FileUtil1 extends ActionSupport {

    public static final String UPLOAD = "upload";

    public String execute() {
        String path = ServletActionContext.getServletContext().getRealPath("/");
        File file = new File(path, UPLOAD);
        if(!file.exists()) {
            file.mkdir();
        }
        return file.getAbsolutePath();
    }

}
