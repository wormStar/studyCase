package cn.stu.intercepter;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

/**
 * Created by sweet on 2017/6/27.
 */
public class MyIntercepter1 extends MethodFilterInterceptor {
    protected String doIntercept(ActionInvocation actionInvocation) throws Exception {
        System.out.println("进入拦截器");
        return actionInvocation.invoke();
    }
}
