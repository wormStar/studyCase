package cn.stu.controller;

import cn.stu.user.User;
import com.opensymphony.xwork2.ActionSupport;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sweet on 2017/6/27.
 */
public class OGNLAction extends ActionSupport {

    private int age;
    private String name;
    private User user;
    private List<User> users;

    public int getAge() {
        return age;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String execute() {
        age = 19;
        name = "mary";
        user = new User();
        user.setEmail("123@.com");
        user.setSex("woman");
        user.setPwd("123456");

        User user1 = new User();
        user1.setEmail("456@.com");
        user1.setSex("man");
        user1.setPwd("654321");


        users  = new ArrayList<User>();
        users.add(user);
        users.add(user1);
        return "success";
    }

}
