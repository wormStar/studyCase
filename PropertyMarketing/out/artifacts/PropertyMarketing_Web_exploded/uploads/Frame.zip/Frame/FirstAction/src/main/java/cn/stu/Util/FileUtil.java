package cn.stu.Util;

import org.apache.struts2.ServletActionContext;

import java.io.File;

/**
 * Created by sweet on 2017/6/29.
 */
public class FileUtil {

    public static final String UPLOAD = "upload";

    public static String uploadPath() {
        String path = ServletActionContext.getServletContext().getRealPath("/");
        File uploads = new File(path, UPLOAD);
        if(!uploads.exists()) {
            uploads.mkdir();
        }
        return uploads.getAbsolutePath();
    }

}
