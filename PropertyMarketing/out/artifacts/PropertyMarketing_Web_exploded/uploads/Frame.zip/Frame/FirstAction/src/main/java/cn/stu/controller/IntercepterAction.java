package cn.stu.controller;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Created by sweet on 2017/6/27.
 */
public class IntercepterAction extends ActionSupport {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String execute() {
        System.out.println("name:" + name);
        return "success";
    }
}
