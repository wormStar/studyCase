package cn.stu.common;

/**
 * Created by sweet on 2017/6/30.
 */
public class DateUtil {

    public static java.sql.Date convert(java.util.Date date) {
        return new java.sql.Date(date.getTime());
    }

}
