package cn.stu.controller;

import cn.stu.bean.Device;
import cn.stu.common.ControllerResult;
import cn.stu.common.Pager;
import cn.stu.service.DeviceService;
import cn.stu.service.impl.DeviceServiceImpl;
import com.opensymphony.xwork2.ActionSupport;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by sweet on 2017/6/30.
 */
public class DeviceAction extends ActionSupport {

    private DeviceService deviceService;

    private Device device;
    private List<Device> devices;
    private int total;
    private int page = 1;
    private int pageSize = 5;
    private int totalPage;

    public int getTotalPage() {
        return totalPage;
    }

    private ControllerResult controllerResult;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public DeviceAction() {
        deviceService = new DeviceServiceImpl();
    }

    public ControllerResult getControllerResult() {
        return controllerResult;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public Device getDevice() {

        return device;
    }

    public List<Device> getDevices() {
        return devices;
    }

    public int getTotal() {
        return total;
    }

    public String add() {
        deviceService.add(device);
        controllerResult = ControllerResult.getSuccessResult("添加成功");
        return "add";
    }

    public String pager() {
        Pager<Device> pager = new Pager<Device>();

        total = deviceService.count();
        totalPage = total % pageSize == 0 ? total / pageSize : (total / pageSize) + 1;
        if(page <= 1){
            page = 1;
        }else if(page >= totalPage) {
            page = totalPage;
        }
        pager.setPage(page);//当前页
        pager.setPageSize(pageSize);//几行
        pager = deviceService.findByPage(pager);
        pager.setTotal(deviceService.count());//总行数
        devices = pager.getResults();

        return "pager";
}

}
