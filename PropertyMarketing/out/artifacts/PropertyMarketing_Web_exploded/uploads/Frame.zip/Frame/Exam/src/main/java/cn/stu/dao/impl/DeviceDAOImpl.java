package cn.stu.dao.impl;

import cn.stu.bean.Device;
import cn.stu.common.DateUtil;
import cn.stu.common.Pager;
import cn.stu.dao.AbstractBaseDAO;
import cn.stu.dao.DeviceDAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sweet on 2017/6/30.
 */
public class DeviceDAOImpl extends AbstractBaseDAO implements DeviceDAO {

    public void add(Device device) {
        getConn();
        try {
            PreparedStatement ps = conn.prepareStatement("insert into device(id, name, price, buyDate) values(uuid(), ?, ?, ?)");
            ps.setString(1, device.getName());
            ps.setDouble(2, device.getPrice());
            ps.setDate(3, DateUtil.convert(device.getBuyDate()));
           ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
    }

    public void update(Device device) {

    }

    public List<Device> all() {
        return null;
    }

    public Device findById(String s) {
        return null;
    }

    public int count() {
        getConn();
        int count = 0;
        try {
            PreparedStatement ps = conn.prepareStatement("select count(id) from device");
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
        return count;
    }

    public void valid(String s, String status) {

    }

    public Pager<Device> findByPage(Pager<Device> pager) {
        getConn();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from device limit ?,?");
            ps.setInt(1, pager.getBeginIndex());
            ps.setInt(2, pager.getPageSize());
            ResultSet rs = ps.executeQuery();
            List<Device> devices = new ArrayList<Device>();
            while(rs.next()) {
                Device device = new Device();
                device.setId(rs.getString("id"));
                device.setName(rs.getString("name"));
                device.setPrice(rs.getDouble("price"));
                device.setStatus(rs.getString("status"));
                device.setUsefiul(rs.getString("usefiul"));
                device.setBuyDate(rs.getDate("buyDate"));
                devices.add(device);
            }
            pager.setResults(devices);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
        return pager;
    }
}
