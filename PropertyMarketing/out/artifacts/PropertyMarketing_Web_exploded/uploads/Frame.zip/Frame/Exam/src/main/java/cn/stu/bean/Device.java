package cn.stu.bean;

import java.util.Date;

/**
 * Created by sweet on 2017/6/30.
 */
public class Device {

    private String id;
    private String name;
    private Double price;
    private String status;
    private Date buyDate;
    private String usefiul;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getBuyDate() {
        return buyDate;
    }

    public void setBuyDate(Date buyDate) {
        this.buyDate = buyDate;
    }

    public String getUsefiul() {
        return usefiul;
    }

    public void setUsefiul(String usefiul) {
        this.usefiul = usefiul;
    }
}
