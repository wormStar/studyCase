package cn.stu.controller;

/**
 * Created by sweet on 2017/6/24.
 */
public class LoginAction {

    private String email;
    private String pwd;

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

public String loginPage() {
        return "loginPage";
}

    public String loginCheck() {
        System.out.println(email + "," + pwd);
        return "success";
    }

}
