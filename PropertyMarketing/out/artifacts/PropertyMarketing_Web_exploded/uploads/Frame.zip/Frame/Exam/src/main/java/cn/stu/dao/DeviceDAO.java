package cn.stu.dao;

import cn.stu.bean.Device;

/**
 * Created by sweet on 2017/6/30.
 */
public interface DeviceDAO extends BaseDAO<String , Device> {


}
