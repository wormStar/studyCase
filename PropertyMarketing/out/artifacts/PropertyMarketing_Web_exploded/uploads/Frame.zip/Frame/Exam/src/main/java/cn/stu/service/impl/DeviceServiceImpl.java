package cn.stu.service.impl;

import cn.stu.bean.Device;
import cn.stu.common.Pager;
import cn.stu.dao.DeviceDAO;
import cn.stu.dao.impl.DeviceDAOImpl;
import cn.stu.service.DeviceService;

import java.util.List;

/**
 * Created by sweet on 2017/6/30.
 */
public class DeviceServiceImpl implements DeviceService {

    private DeviceDAO deviceDAO;

    public DeviceServiceImpl() {
        deviceDAO = new DeviceDAOImpl();
    }

    public void add(Device device) {
        deviceDAO.add(device);
    }

    public void update(Device device) {

    }

    public List<Device> all() {
        return null;
    }

    public Device findById(String s) {
        return null;
    }

    public int count() {
        return deviceDAO.count();
    }

    public void valid(String s, String status) {

    }

    public Pager<Device> findByPage(Pager<Device> pager) {
        return deviceDAO.findByPage(pager);
    }
}
