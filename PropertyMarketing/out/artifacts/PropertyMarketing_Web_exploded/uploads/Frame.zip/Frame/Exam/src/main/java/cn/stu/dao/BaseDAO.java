package cn.stu.dao;

import cn.stu.common.Pager;

import java.util.List;

/**
 * Created by sweet on 2017/6/30.
 */
public interface BaseDAO<PK, T> {

    public void add(T t);

    public void update(T t);

    public List<T> all();

    public T findById(PK pk);

    public int count();

    public void valid(PK pk, String status);

    public Pager<T> findByPage(Pager<T> pager);
}
