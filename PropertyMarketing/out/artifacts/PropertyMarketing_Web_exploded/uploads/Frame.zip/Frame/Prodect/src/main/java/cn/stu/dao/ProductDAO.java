package cn.stu.dao;

import cn.stu.bean.Product;

/**
 * Created by sweet on 2017/7/17.
 */
public interface ProductDAO extends BaseDAO<Integer, Product> {

}
