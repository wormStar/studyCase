package cn.stu.service;

import cn.stu.common.Pager;

import java.util.List;

/**
 * Created by sweet on 2017/7/17.
 */
public interface BaseService<PK, T> {
    public void add(T t);
    public void update(T t);
    public List<T> all();
    public T deleteById(PK pk);
    public T findById(PK pk);
    public int count();
    public void volid(PK pk, String status);
    public Pager<T> findByPager(Pager<T> pager);
}
