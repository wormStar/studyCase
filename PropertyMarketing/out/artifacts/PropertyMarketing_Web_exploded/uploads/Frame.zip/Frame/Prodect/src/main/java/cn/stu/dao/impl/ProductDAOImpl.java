package cn.stu.dao.impl;

import cn.stu.bean.Product;
import cn.stu.common.Pager;
import cn.stu.common.DateUtil;
import cn.stu.dao.AbstractBaseDAO;
import cn.stu.dao.ProductDAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sweet on 2017/7/17.
 */
public class ProductDAOImpl extends AbstractBaseDAO implements ProductDAO {
    public void add(Product product) {
        getCo();
        try {
            PreparedStatement ps = co.prepareStatement("insert into product(name, counts, price, salePrice, date) values(?,?,?,?,?)");
            ps.setString(1, product.getName());
            ps.setInt(2, product.getCounts());
            ps.setDouble(3, product.getPrice());
            ps.setDouble(4, product.getSalePrice());
            ps.setDate(5, DateUtil.convetor(product.getDate()));
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
    }

    public void update(Product product) {
        getCo();
        try {
            PreparedStatement ps = co.prepareStatement("update product set name=?, counts=?, price=?, salePrice=?, date=? where id=?");
            ps.setString(1, product.getName());
            ps.setInt(2, product.getCounts());
            ps.setDouble(3, product.getPrice());
            ps.setDouble(4, product.getSalePrice());
            ps.setDate(5, DateUtil.convetor(product.getDate()));
            ps.setInt(6, product.getId());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
    }

    public List<Product> all() {
        getCo();
        List<Product> products = new ArrayList<Product>();
        try {
            PreparedStatement ps = co.prepareStatement("select * from product");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setSalePrice(rs.getDouble("salePrice"));
                product.setDate(DateUtil.reConvetor(rs.getDate("date")));
                product.setStatus(rs.getString("status"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
        return null;
    }

    public Product deleteById(Integer integer) {
        return null;
    }

    public Product findById(Integer integer) {
        return null;
    }

    public int count() {
        getCo();
        int count = 0;
        try {
            PreparedStatement ps = co.prepareStatement("select count(id) from product");
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
        return count;
    }

    public void volid(Integer integer, String status) {
        getCo();
        try {
            PreparedStatement ps = co.prepareStatement("update product set status=? where id=?");
            ps.setString(1, status);
            ps.setInt(2, integer);
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
    }

    public Pager<Product> findByPager(Pager<Product> pager) {
        getCo();
        try {
            PreparedStatement ps = co.prepareStatement("select * from product order by id DESC limit ?,?");
            ps.setInt(1, pager.beginIndex());
            ps.setInt(2, pager.getPageSize());
            ResultSet rs = ps.executeQuery();
            List<Product> products = new ArrayList<Product>();
            while(rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setCounts(rs.getInt("counts"));
                product.setPrice(rs.getDouble("price"));
                product.setSalePrice(rs.getDouble("salePrice"));
                product.setStatus(rs.getString("status"));
                product.setDate(DateUtil.reConvetor(rs.getDate("date")));
                products.add(product);
            }
            pager.setResults(products);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        close();
        return pager;
    }
}
