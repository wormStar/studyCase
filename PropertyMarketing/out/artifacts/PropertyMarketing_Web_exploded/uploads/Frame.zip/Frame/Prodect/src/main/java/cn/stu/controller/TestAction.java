package cn.stu.controller;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Created by sweet on 2017/7/18.
 */
public class TestAction extends ActionSupport {

    public String test() {
        System.out.println("test");
        return "test";
    }

}
