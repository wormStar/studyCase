package cn.stu.service;

import cn.stu.bean.Product;

/**
 * Created by sweet on 2017/7/17.
 */
public interface ProductService extends BaseService<Integer, Product> {
}
