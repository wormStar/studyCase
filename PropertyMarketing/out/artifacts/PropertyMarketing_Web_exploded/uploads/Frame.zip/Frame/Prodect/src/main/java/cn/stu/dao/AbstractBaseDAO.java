package cn.stu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by sweet on 2017/7/17.
 */
public class AbstractBaseDAO {
    protected Connection co;

    public void getCo(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            co = DriverManager.getConnection("jdbc:mysql://localhost:3306/device?useUnicode=true&characterEncoding=utf-8","root","123456");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void close(){
        try {
            if(co!=null && !co.isClosed()) {
                co.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
