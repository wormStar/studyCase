package cn.stu.service.impl;

import cn.stu.bean.Product;
import cn.stu.common.Pager;
import cn.stu.dao.ProductDAO;
import cn.stu.dao.impl.ProductDAOImpl;
import cn.stu.service.ProductService;

import java.util.List;

/**
 * Created by sweet on 2017/7/17.
 */
public class ProductServiceImpl implements ProductService {

    private ProductDAO productDAO;
    public ProductServiceImpl(){
        productDAO = new ProductDAOImpl();
    }

    public void add(Product product) {
        productDAO.add(product);
    }

    public void update(Product product) {
        productDAO.update(product);
    }

    public List<Product> all() {
        return productDAO.all();
    }

    public Product deleteById(Integer integer) {
        return productDAO.deleteById(integer);
    }

    public Product findById(Integer integer) {
        return productDAO.findById(integer);
    }

    public int count() {
        return productDAO.count();
    }

    public void volid(Integer integer, String status) {
        productDAO.volid(integer, status);
    }

    public Pager<Product> findByPager(Pager<Product> pager) {
        return productDAO.findByPager(pager);
    }
}
