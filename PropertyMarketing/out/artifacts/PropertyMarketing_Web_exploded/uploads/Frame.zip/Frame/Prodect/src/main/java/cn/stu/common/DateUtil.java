package cn.stu.common;

/**
 * Created by sweet on 2017/7/17.
 */
public class DateUtil {

    public static java.sql.Date convetor(java.util.Date date) {
        return new java.sql.Date(date.getTime());
    }

    public static java.util.Date reConvetor(java.sql.Date date) {
        return new java.util.Date(date.getTime());
    }

}
