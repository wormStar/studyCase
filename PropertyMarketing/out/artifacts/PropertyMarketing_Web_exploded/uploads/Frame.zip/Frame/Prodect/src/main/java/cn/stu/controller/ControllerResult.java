package cn.stu.controller;

/**
 * Created by sweet on 2017/7/18.
 */
public class ControllerResult {

    public static final String SUCCESS = "success";
    public static final String FAIL = "fail";
    private String message;
    private String result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public static ControllerResult getSuccessResult(String message) {
        ControllerResult controllerResult = new ControllerResult();
        controllerResult.setMessage(SUCCESS);
        controllerResult.setResult(message);
        return controllerResult;
    }

    public static ControllerResult getFailResult(String message){
        ControllerResult controllerResult = new ControllerResult();
        controllerResult.setMessage(FAIL);
        controllerResult.setMessage(message);
        return controllerResult;
    }

}
